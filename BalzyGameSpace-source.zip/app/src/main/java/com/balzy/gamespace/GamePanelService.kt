package com.balzy.gamespace

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*

class GamePanelService: Service() {
    private lateinit var wm: WindowManager
    private var handle: View? = null
    private var panel: View? = null
    private var cross: View? = null
    private var targetPackage: String? = null
    private var monitor: Handler? = null
    private var open = false
    private var down = 0f
    private val red=Color.rgb(255,35,55)

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun bg(c:Int,r:Int)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()}

    override fun onCreate(){
        super.onCreate()
        channel()
        startForeground(77,notification())
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        monitor=Handler(Looper.getMainLooper())
    }

    private fun channel(){
        if(Build.VERSION.SDK_INT>=26){
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel("balzy_game","BalzyGameSpace",NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(): Notification =
        Notification.Builder(this,"balzy_game")
            .setSmallIcon(R.drawable.ic_balzy)
            .setContentTitle("BalzyGameSpace")
            .setContentText("Game monitor ready")
            .setOngoing(true)
            .setContentIntent(
                PendingIntent.getActivity(
                    this,0,Intent(this,MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            ).build()

    private fun params(w:Int,h:Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w,h,
            if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )

    private fun startMonitor(){
        val h=monitor ?: return
        h.removeCallbacksAndMessages(null)
        val task=object:Runnable{
            override fun run(){
                val target=targetPackage ?: run { stopSelf(); return }
                if(!ShizukuHelper.isGranted()){
                    hidePanel(); hideHandle()
                    h.postDelayed(this,1500)
                    return
                }
                ShizukuHelper.foregroundPackage { current ->
                    h.post {
                        if(current==target){
                            if(handle==null) addHandle()
                        }else{
                            hidePanel()
                            hideHandle()
                        }
                        h.postDelayed(this,700)
                    }
                }
            }
        }
        h.post(task)
    }

    private fun addHandle(){
        if(handle!=null || !Settings.canDrawOverlays(this)) return
        val v=View(this).apply{
            background=bg(red,10)
            setOnTouchListener{_,e->
                when(e.actionMasked){
                    MotionEvent.ACTION_DOWN->{down=e.rawX;true}
                    MotionEvent.ACTION_UP->{if(e.rawX-down>dp(42))show();true}
                    else->true
                }
            }
        }
        handle=v
        val p=params(dp(6),dp(78))
        p.gravity=Gravity.LEFT or Gravity.CENTER_VERTICAL
        try{wm.addView(v,p)}catch(_:Exception){handle=null}
    }

    private fun show(){
        if(open || handle==null) return
        open=true
        handle?.visibility=View.GONE

        val box=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(14),dp(14),dp(12),dp(13))
            background=bg(Color.rgb(9,9,12),24)
        }

        val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        top.addView(ImageView(this).apply{setImageResource(R.drawable.ic_balzy)},
            LinearLayout.LayoutParams(dp(38),dp(38)))
        top.addView(TextView(this).apply{
            text="BalzyGameSpace\nGAME PANEL"
            textSize=11f
            setTextColor(Color.WHITE)
            setPadding(dp(8),0,0,0)
        },LinearLayout.LayoutParams(0,dp(44),1f))
        top.addView(ImageButton(this).apply{
            setImageResource(R.drawable.ic_close)
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(dp(8),dp(8),dp(8),dp(8))
            setOnClickListener{hidePanel()}
        },LinearLayout.LayoutParams(dp(42),dp(42)))
        box.addView(top)

        box.addView(TextView(this).apply{
            text="●  ACTIVE     RAM ${ram()}     ${Build.MODEL}"
            textSize=9f
            setTextColor(red)
            setPadding(0,dp(7),0,dp(9))
        })

        val g=GridLayout(this).apply{columnCount=2}
        tool(g,R.drawable.ic_volume,"VOLUME"){volume()}
        tool(g,R.drawable.ic_brightness,"BRIGHTNESS"){brightness()}
        tool(g,R.drawable.ic_crosshair,"CROSSHAIR"){toggleCross()}
        tool(g,R.drawable.ic_dnd,"DND MODE"){dnd()}
        tool(g,R.drawable.ic_record,"RECORD"){
            Toast.makeText(this@GamePanelService,"Screen recording requires Android MediaProjection approval.",Toast.LENGTH_LONG).show()
        }
        tool(g,R.drawable.ic_bolt,"BOOST"){
            Toast.makeText(this@GamePanelService,"Focus mode selected. OEM CPU/GPU controls need manufacturer APIs.",Toast.LENGTH_LONG).show()
        }
        box.addView(g)

        val p=params((resources.displayMetrics.widthPixels*.88f).toInt(),dp(300))
        p.gravity=Gravity.LEFT or Gravity.CENTER_VERTICAL
        p.x=0
        panel=box
        try{
            wm.addView(box,p)
            box.alpha=0f
            box.translationX=-dp(60).toFloat()
            box.animate().alpha(1f).translationX(0f).setDuration(220).start()
        }catch(_:Exception){
            panel=null
            open=false
        }
    }

    private fun tool(g:GridLayout,icon:Int,name:String,a:()->Unit){
        val c=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            gravity=Gravity.CENTER
            background=bg(Color.rgb(17,17,21),17)
            setOnClickListener{a()}
        }
        c.addView(ImageView(this).apply{setImageResource(icon)},
            LinearLayout.LayoutParams(dp(27),dp(27)))
        c.addView(TextView(this).apply{
            text=name;textSize=9f;setTextColor(Color.WHITE);gravity=Gravity.CENTER
        })
        val p=GridLayout.LayoutParams()
        p.width=0;p.height=dp(76)
        p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1,1f)
        p.setMargins(dp(3),dp(3),dp(3),dp(3))
        g.addView(c,p)
    }

    private fun volume(){
        val a=getSystemService(AUDIO_SERVICE) as AudioManager
        val c=a.getStreamVolume(AudioManager.STREAM_MUSIC)
        val m=a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        a.setStreamVolume(AudioManager.STREAM_MUSIC,if(c>=m)0 else c+1,AudioManager.FLAG_SHOW_UI)
    }

    private fun brightness(){
        if(!Settings.System.canWrite(this)){
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        val v=Settings.System.getInt(contentResolver,Settings.System.SCREEN_BRIGHTNESS,128)
        Settings.System.putInt(contentResolver,Settings.System.SCREEN_BRIGHTNESS,if(v>180)90 else 220)
    }

    private fun dnd(){
        startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun toggleCross(){
        if(cross!=null){
            runCatching{wm.removeView(cross)}
            cross=null
            return
        }
        cross=TextView(this).apply{text="+";textSize=30f;setTextColor(red);gravity=Gravity.CENTER}
        val p=params(dp(70),dp(70));p.gravity=Gravity.CENTER
        try{wm.addView(cross,p)}catch(_:Exception){cross=null}
    }

    private fun hidePanel(){
        panel?.let{runCatching{wm.removeView(it)}}
        panel=null
        open=false
    }

    private fun hideHandle(){
        handle?.let{runCatching{wm.removeView(it)}}
        handle=null
    }

    private fun ram():String{
        val i=ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(i)
        return "${(i.totalMem-i.availMem)/1024/1024}MB"
    }

    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        targetPackage=intent?.getStringExtra("gamePackage") ?: targetPackage
        if(targetPackage.isNullOrBlank()){
            stopSelf()
            return START_NOT_STICKY
        }
        startMonitor()
        return START_STICKY
    }

    override fun onDestroy(){
        monitor?.removeCallbacksAndMessages(null)
        hidePanel()
        hideHandle()
        cross?.let{runCatching{wm.removeView(it)}}
        cross=null
        super.onDestroy()
    }

    override fun onBind(intent:Intent?)=null
}
