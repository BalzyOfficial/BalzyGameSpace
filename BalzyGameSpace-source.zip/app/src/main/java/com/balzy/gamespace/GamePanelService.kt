package com.balzy.gamespace

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*
import kotlin.math.abs

class GamePanelService : Service() {
    private lateinit var wm: WindowManager
    private var handle: View? = null
    private var panel: View? = null
    private var downX = 0f
    private var downY = 0f
    private var panelOpen = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(77, notification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addHandle()
    }

    private fun addHandle() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        val h = TextView(this).apply {
            text = "›"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundResource(R.drawable.edge_handle)
            setOnTouchListener { _, e ->
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; true }
                    MotionEvent.ACTION_UP -> {
                        val dx=e.rawX-downX
                        if (dx > 70) openPanel()
                        true
                    }
                    else -> true
                }
            }
        }
        handle=h
        wm.addView(h, params(0, WindowManager.LayoutParams.MATCH_PARENT, 18, Gravity.LEFT or Gravity.CENTER_VERTICAL))
    }

    private fun openPanel() {
        if (panelOpen) return
        panelOpen=true
        panel=buildPanel()
        wm.addView(panel, panelParams())
        handle?.visibility=View.GONE
    }

    private fun closePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel=null
        panelOpen=false
        handle?.visibility=View.VISIBLE
    }

    private fun buildPanel(): View {
        val box=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(18,18,18,18)
            background=getDrawable(R.drawable.panel_bg)
        }
        val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        val logo=ImageView(this).apply{setImageResource(R.drawable.ic_balzy)}
        top.addView(logo,LinearLayout.LayoutParams(42,42))
        val title=TextView(this).apply{
            text="BalzyGameSpace";textSize=17f;setTextColor(Color.WHITE)
            typeface=android.graphics.Typeface.DEFAULT_BOLD;setPadding(10,0,0,0)
        }
        top.addView(title,LinearLayout.LayoutParams(0,50,1f))
        val x=TextView(this).apply{text="×";textSize=27f;setTextColor(Color.WHITE);gravity=Gravity.CENTER}
        x.setOnClickListener{closePanel()}
        top.addView(x,LinearLayout.LayoutParams(42,50))
        box.addView(top)

        val stats=LinearLayout(this).apply{gravity=Gravity.CENTER}
        listOf("FPS\n60","CPU\n42%","RAM\n3.8G","TEMP\n38°C").forEach{
            val t=TextView(this).apply{text=it;textSize=12f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setPadding(8,10,8,10);background=getDrawable(R.drawable.card_bg)}
            val lp=LinearLayout.LayoutParams(0,60,1f);lp.setMargins(3,5,3,10);stats.addView(t,lp)
        }
        box.addView(stats)

        val grid=GridLayout(this).apply{columnCount=2}
        val items=listOf("🚀  Booster","📊  Monitor","🎯  Touch","📸  Screenshot","🎥  Record","🔕  DND","🎯  Crosshair","🔒  Lock Touch")
        items.forEach{name->
            val b=TextView(this).apply{
                text=name;textSize=12f;gravity=Gravity.CENTER_VERTICAL;setTextColor(Color.WHITE)
                setPadding(14,0,10,0);background=getDrawable(R.drawable.card_bg)
                setOnClickListener{Toast.makeText(this@GamePanelService,"$name • UI aktif",Toast.LENGTH_SHORT).show()}
            }
            val lp=GridLayout.LayoutParams().apply{width=0;height=54;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(3,3,3,3)}
            grid.addView(b,lp)
        }
        box.addView(grid)

        val perf=TextView(this).apply{
            text="⚡  PERFORMANCE MODE     •     EXTREME"
            textSize=12f;setTextColor(Color.WHITE);gravity=Gravity.CENTER
            setPadding(8,15,8,15);background=getDrawable(R.drawable.card_bg)
            setOnClickListener{Toast.makeText(this@GamePanelService,"Performance UI dipilih",Toast.LENGTH_SHORT).show()}
        }
        box.addView(perf)
        return box
    }

    private fun params(x:Int,y:Int,w:Int,h:Int,gravity:Int=Gravity.LEFT or Gravity.CENTER_VERTICAL)=WindowManager.LayoutParams(
        w,h, if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply{this.gravity=gravity;this.x=x;this.y=y}

    private fun panelParams()=WindowManager.LayoutParams(
        (resources.displayMetrics.widthPixels*0.86f).toInt(),
        WindowManager.LayoutParams.WRAP_CONTENT,
        if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply{gravity=Gravity.LEFT or Gravity.CENTER_VERTICAL;x=8}

    private fun createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            val ch=NotificationChannel("balzy_game","BalzyGameSpace",NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun notification():Notification{
        val pi=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this,"balzy_game")
            .setSmallIcon(R.drawable.ic_balzy)
            .setContentTitle("BalzyGameSpace aktif")
            .setContentText("Swipe dari tepi kiri ke tengah untuk membuka Game Panel.")
            .setContentIntent(pi).setOngoing(true).build()
    }

    override fun onDestroy(){
        closePanel()
        handle?.let{runCatching{wm.removeView(it)}}
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder?=null
}
