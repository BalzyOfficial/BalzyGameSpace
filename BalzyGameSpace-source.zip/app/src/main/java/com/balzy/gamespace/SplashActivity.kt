package com.balzy.gamespace

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setBackgroundColor(android.graphics.Color.rgb(5,5,5))
            setPadding(36, 0, 36, 0)
        }

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_balzy)
            alpha = 0f
            scaleX = .65f
            scaleY = .65f
        }
        root.addView(logo, LinearLayout.LayoutParams(150, 150))

        val title = TextView(this).apply {
            text = "BALZY${"GAME".let { it }}SPACE"
            textSize = 27f
            setTextColor(android.graphics.Color.WHITE)
            gravity = android.view.Gravity.CENTER
            alpha = 0f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val sub = TextView(this).apply {
            text = "PLAY  •  BOOST  •  ENJOY"
            textSize = 12f
            setTextColor(android.graphics.Color.rgb(255, 27, 45))
            gravity = android.view.Gravity.CENTER
            alpha = 0f
            letterSpacing = .16f
        }
        root.addView(sub, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)

        AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(logo, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(logo, View.SCALE_X, .65f, 1f),
                ObjectAnimator.ofFloat(logo, View.SCALE_Y, .65f, 1f),
                ObjectAnimator.ofFloat(title, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(sub, View.ALPHA, 0f, 1f)
            )
            duration = 850
            interpolator = DecelerateInterpolator()
            start()
        }

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, 1500)
    }
}
