package com.balzy.gamespace
import android.animation.*
import android.content.Intent
import android.graphics.Color
import android.os.*
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SplashActivity:AppCompatActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);window.statusBarColor=Color.BLACK;window.navigationBarColor=Color.BLACK
  val r=FrameLayout(this).apply{setBackgroundColor(Color.rgb(5,5,7))}
  val stripe=View(this).apply{setBackgroundColor(Color.rgb(120,8,18));rotation=-18f;alpha=0f};r.addView(stripe,FrameLayout.LayoutParams(dp(650),dp(80),Gravity.CENTER))
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(30),0,dp(30),0)}
  val logo=ImageView(this).apply{setImageResource(R.drawable.ic_balzy);alpha=0f;scaleX=.55f;scaleY=.55f};box.addView(logo,LinearLayout.LayoutParams(dp(132),dp(132)))
  box.addView(TextView(this).apply{text="BALZYGAMESPACE";textSize=25f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;typeface=android.graphics.Typeface.DEFAULT_BOLD;alpha=0f},LinearLayout.LayoutParams(-1,dp(45)))
  box.addView(TextView(this).apply{text="PLAY  •  BOOST  •  CONTROL";textSize=10f;letterSpacing=.18f;setTextColor(Color.rgb(255,35,55));gravity=Gravity.CENTER;alpha=0f},LinearLayout.LayoutParams(-1,dp(30)))
  r.addView(box,FrameLayout.LayoutParams(-1,-1))
  setContentView(r)
  stripe.animate().alpha(.75f).translationX(dp(180).toFloat()).setDuration(700).start();logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).setStartDelay(180).start();box.getChildAt(1).animate().alpha(1f).setStartDelay(430).setDuration(400).start();box.getChildAt(2).animate().alpha(1f).setStartDelay(600).setDuration(400).start()
  Handler(Looper.getMainLooper()).postDelayed({startActivity(Intent(this,MainActivity::class.java));overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);finish()},1500)
 }
 private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}
