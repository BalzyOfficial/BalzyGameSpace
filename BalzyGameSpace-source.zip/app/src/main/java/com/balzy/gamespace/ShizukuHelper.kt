
package com.balzy.gamespace

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors
import java.util.regex.Pattern

object ShizukuHelper {
    const val REQUEST_CODE = 9001
    private val io = Executors.newCachedThreadPool()

    fun isAvailable(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun isGranted(): Boolean = try {
        isAvailable() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun requestPermission(onResult: ((Boolean) -> Unit)? = null) {
        if (!isAvailable()) {
            onResult?.invoke(false)
            return
        }
        try {
            if (isGranted()) { onResult?.invoke(true); return }
            val listener = object : Shizuku.OnRequestPermissionResultListener {
                override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
                    if (requestCode != REQUEST_CODE) return
                    Shizuku.removeRequestPermissionResultListener(this)
                    onResult?.invoke(grantResult == PackageManager.PERMISSION_GRANTED)
                }
            }
            Shizuku.addRequestPermissionResultListener(listener)
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) { onResult?.invoke(false) }
    }

    fun execute(command: String, callback: (String) -> Unit) {
        io.execute {
            var output = ""
            try {
                val p = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                output = p.inputStream.bufferedReader().use { it.readText() }
                p.destroy()
            } catch (_: Throwable) {}
            callback(output.trim())
        }
    }

    fun foregroundPackage(callback: (String?) -> Unit) {
        if (!isGranted()) { callback(null); return }
        execute("dumpsys activity activities | grep -E 'mResumedActivity|mFocusedApp' | head -n 2") { out ->
            val patterns = listOf(
                Pattern.compile("""\bu\d+\s+([A-Za-z0-9_.$]+)/(?:[A-Za-z0-9_.$]+)"""),
                Pattern.compile("""\s([A-Za-z0-9_.$]+)/[A-Za-z0-9_.$]+""")
            )
            var found: String? = null
            for (line in out.lines()) {
                for (p in patterns) {
                    val mm=p.matcher(line)
                    if (mm.find()) { found=mm.group(1); break }
                }
                if(found!=null) break
            }
            callback(found)
        }
    }

    fun openShizuku(context: Context) {
        try {
            val launch=context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if(launch!=null) context.startActivity(launch)
            else context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://shizuku.rikka.app/download/")))
        } catch (_:Throwable) {
            context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://shizuku.rikka.app/download/")))
        }
    }

    fun openWirelessDebugging(context: Context) {
        try {
            context.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        } catch (_:Throwable) {
            try { context.startActivity(Intent(Settings.ACTION_DEVELOPMENT_SETTINGS)) }
            catch (_:Throwable) { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
    }
}
