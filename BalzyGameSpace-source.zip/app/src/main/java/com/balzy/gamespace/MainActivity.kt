package com.balzy.gamespace

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale

private data class GameEntry(val pkg:String, val label:String)

class MainActivity: AppCompatActivity(){
    private val red=Color.rgb(255,35,55); private val muted=Color.rgb(145,145,154); private val bg=Color.rgb(5,5,7)
    private val prefs by lazy{getSharedPreferences("balzy_games",MODE_PRIVATE)}
    private lateinit var grid:GridLayout
    private val games=mutableListOf<GameEntry>()
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun tv(s:String,z:Float,c:Int=Color.WHITE,b:Boolean=false)=TextView(this).apply{text=s;textSize=z;setTextColor(c);if(b)typeface=Typeface.DEFAULT_BOLD}
    private fun bg(c:Int,r:Int,stroke:Int=0,sc:Int=Color.TRANSPARENT)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat();if(stroke>0)setStroke(dp(stroke),sc)}

    override fun onCreate(b:Bundle?){super.onCreate(b);window.statusBarColor=Color.BLACK;window.navigationBarColor=Color.BLACK;build();loadGames();requestNotify()}

    private fun build(){
        val root=FrameLayout(this).apply{setBackgroundResource(R.drawable.bg_gradient)}
        val scroll=ScrollView(this).apply{clipToPadding=false}
        val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(10),dp(18),dp(95))}
        scroll.addView(content,ViewGroup.LayoutParams(-1,-2));root.addView(scroll,FrameLayout.LayoutParams(-1,-1))

        val head=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        val logo=ImageView(this).apply{setImageResource(R.drawable.ic_balzy)};head.addView(logo,LinearLayout.LayoutParams(dp(42),dp(42)))
        val brand=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)}
        brand.addView(tv("BalzyGameSpace",18f,Color.WHITE,true));brand.addView(tv("GAME SPACE  •  ONLINE",9f,red,true));head.addView(brand,LinearLayout.LayoutParams(0,-2,1f))
        val set=ImageButton(this).apply{setImageResource(R.drawable.ic_settings);setBackgroundColor(Color.TRANSPARENT);setPadding(dp(10),dp(10),dp(10),dp(10));setOnClickListener{settings()}}
        head.addView(set,LinearLayout.LayoutParams(dp(46),dp(46)));content.addView(head,LinearLayout.LayoutParams(-1,dp(52)))

        val hero=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(19),dp(20),dp(18));background=getDrawable(R.drawable.bg_gradient,null)}
        val hrow=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        val ht=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        ht.addView(tv("WELCOME BACK",10f,red,true));ht.addView(tv("PLAY WITHOUT\nLIMITS.",27f,Color.WHITE,true));ht.addView(tv("Launch your selected game and bring the\nBalzyGameSpace panel into the action.",11f,muted))
        hrow.addView(ht,LinearLayout.LayoutParams(0,-2,1f));val bolt=ImageView(this).apply{setImageResource(R.drawable.ic_bolt);setPadding(dp(7),dp(7),dp(7),dp(7))};hrow.addView(bolt,LinearLayout.LayoutParams(dp(58),dp(58)));hero.addView(hrow)
        val open=button("OPEN GAME SPACE");open.setOnClickListener{if(games.isEmpty())addGames()else launch(games[0])};val olp=LinearLayout.LayoutParams(-1,dp(47));olp.topMargin=dp(15);hero.addView(open,olp)
        val lp=LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(10);content.addView(hero,lp)

        addTitle(content,"MY GAMES","+ ADD GAME"){addGames()}
        grid=GridLayout(this).apply{columnCount=2};content.addView(grid,LinearLayout.LayoutParams(-1,-2))
        addTitle(content,"GAME-LABS","VIEW ALL"){labs()}
        val labRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        labRow.addView(lab(R.drawable.ic_crosshair,"CROSSHAIR"){crosshair()},weight());labRow.addView(lab(R.drawable.ic_volume,"VOLUME"){volume()},weight());labRow.addView(lab(R.drawable.ic_brightness,"BRIGHTNESS"){brightness()},weight());labRow.addView(lab(R.drawable.ic_dnd,"DND"){dnd()},weight())
        content.addView(labRow,LinearLayout.LayoutParams(-1,dp(116)))
        addTitle(content,"GAME PANEL","IN-GAME"){startPanel()}
        val panel=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=bg(Color.rgb(14,14,18),19,1,Color.rgb(43,25,29));setPadding(dp(13),dp(10),dp(10),dp(10))}
        val pi=ImageView(this).apply{setImageResource(R.drawable.ic_bolt)};panel.addView(pi,LinearLayout.LayoutParams(dp(38),dp(38)));val pt=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)};pt.addView(tv("EDGE GAME PANEL",13f,Color.WHITE,true));pt.addView(tv("Swipe from the left edge while playing.",10f,muted));panel.addView(pt,LinearLayout.LayoutParams(0,-2,1f));val go=tv("OPEN",10f,red,true);go.setOnClickListener{startPanel()};panel.addView(go,LinearLayout.LayoutParams(dp(55),dp(42)));content.addView(panel)

        val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=getDrawable(R.drawable.panel_bg,null);setPadding(dp(6),dp(4),dp(6),dp(4))}
        nav.addView(navItem(R.drawable.ic_gamepad,"GAMES",true){scroll.smoothScrollTo(0,0)},weight());nav.addView(navItem(R.drawable.ic_tools,"LABS",false){labs()},weight());nav.addView(navItem(R.drawable.ic_bolt,"BOOST",false){boost()},weight());nav.addView(navItem(R.drawable.ic_settings,"SETTINGS",false){settings()},weight())
        val np=FrameLayout.LayoutParams(-1,dp(65),Gravity.BOTTOM);np.setMargins(dp(12),0,dp(12),dp(9));root.addView(nav,np);setContentView(root)
    }
    private fun weight()=LinearLayout.LayoutParams(0,dp(55),1f)
    private fun addTitle(c:LinearLayout,a:String,b:String,click:()->Unit){val r=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL};r.addView(tv(a,12f,Color.WHITE,true),LinearLayout.LayoutParams(0,dp(45),1f));r.addView(tv(b,9f,red,true).apply{setOnClickListener{click()};setPadding(dp(5),0,dp(3),0)});c.addView(r)}
    private fun button(s:String)=TextView(this).apply{text=s;textSize=11f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);typeface=Typeface.DEFAULT_BOLD;background=getDrawable(R.drawable.red_button,null)}
    private fun navItem(icon:Int,label:String,active:Boolean,click:()->Unit)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setOnClickListener{click()};addView(ImageView(this@MainActivity).apply{setImageResource(icon);setColorFilter(if(active)red) },LinearLayout.LayoutParams(dp(23),dp(25)));addView(tv(label,8f,if(active)red else muted,true))}
    private fun lab(icon:Int,label:String,click:()->Unit)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;background=bg(Color.rgb(13,13,17),17,1,Color.rgb(35,35,41));setOnClickListener{click()};addView(ImageView(this@MainActivity).apply{setImageResource(icon)},LinearLayout.LayoutParams(dp(29),dp(29)));addView(tv(label,8f,Color.WHITE,true))}

    private fun loadGames(){games.clear();prefs.getStringSet("packages",emptySet())!!.forEach{p->runCatching{val a=packageManager.getApplicationInfo(p,0);games.add(GameEntry(p,packageManager.getApplicationLabel(a).toString()))}};renderGames()}
    private fun renderGames(){if(!::grid.isInitialized)return;grid.removeAllViews();if(games.isEmpty()){val e=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;background=bg(Color.rgb(13,13,17),19,1,Color.rgb(35,35,41));setPadding(dp(12),dp(18),dp(12),dp(18));setOnClickListener{addGames()}};e.addView(ImageView(this).apply{setImageResource(R.drawable.ic_add)},LinearLayout.LayoutParams(dp(30),dp(30)));e.addView(tv("NO GAMES YET",11f,Color.WHITE,true));e.addView(tv("Add games manually to your space",9f,muted));val p=GridLayout.LayoutParams();p.width=0;p.height=dp(132);p.columnSpec=GridLayout.spec(0,2,1f);p.setMargins(dp(4),dp(4),dp(4),dp(4));grid.addView(e,p);return};games.forEachIndexed{i,g->grid.addView(game(g,i))}}
    private fun game(g:GameEntry,i:Int):View{val c=FrameLayout(this).apply{background=bg(Color.rgb(13,13,17),19,1,Color.rgb(35,35,41));setOnLongClickListener{remove(g);true}};val ic=ImageView(this).apply{setImageDrawable(packageManager.getApplicationIcon(g.pkg))};c.addView(ic,FrameLayout.LayoutParams(dp(54),dp(54),Gravity.TOP or Gravity.LEFT));val name=tv(g.label,11f,Color.WHITE,true).apply{maxLines=2};val nl=FrameLayout.LayoutParams(-1,dp(34),Gravity.BOTTOM or Gravity.LEFT);nl.rightMargin=dp(45);c.addView(name,nl);val play=ImageButton(this).apply{setImageResource(R.drawable.ic_play);background=getDrawable(R.drawable.red_button,null);setPadding(dp(8),dp(8),dp(8),dp(8));setOnClickListener{launch(g)}};c.addView(play,FrameLayout.LayoutParams(dp(38),dp(38),Gravity.RIGHT or Gravity.BOTTOM));val p=GridLayout.LayoutParams();p.width=0;p.height=dp(132);p.columnSpec=GridLayout.spec(i%2,1,1f);p.setMargins(dp(4),dp(4),dp(4),dp(4));c.layoutParams=p;return c}
    private fun addGames(){val intent=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);val apps=packageManager.queryIntentActivities(intent,PackageManager.MATCH_ALL).filter{it.activityInfo.packageName!=packageName}.distinctBy{it.activityInfo.packageName}.sortedBy{it.loadLabel(packageManager).toString().lowercase(Locale.getDefault())};val names=apps.map{it.loadLabel(packageManager).toString()}.toTypedArray();val checked=apps.map{a->games.any{it.pkg==a.activityInfo.packageName}}.toBooleanArray();AlertDialog.Builder(this).setTitle("ADD GAMES MANUALLY").setMultiChoiceItems(names,checked){_,w,v->checked[w]=v}.setNegativeButton("CANCEL",null).setPositiveButton("SAVE"){_,_->prefs.edit().putStringSet("packages",apps.mapIndexedNotNull{i,a->if(checked[i])a.activityInfo.packageName else null}.toSet()).apply();loadGames()}.show()}
    private fun remove(g:GameEntry){AlertDialog.Builder(this).setTitle("Remove ${g.label}?").setMessage("Only the shortcut is removed. The original game stays installed.").setNegativeButton("CANCEL",null).setPositiveButton("REMOVE"){_,_->val s=prefs.getStringSet("packages",emptySet())!!.toMutableSet();s.remove(g.pkg);prefs.edit().putStringSet("packages",s).apply();loadGames()}.show()}
    private fun launch(g:GameEntry){
        val i=packageManager.getLaunchIntentForPackage(g.pkg)?:return
        if(!Settings.canDrawOverlays(this)){
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))
            Toast.makeText(this,"Allow overlay first, then launch again.",Toast.LENGTH_LONG).show()
            return
        }
        if(!ShizukuHelper.isAvailable()){
            showShizukuSetup()
            return
        }
        if(!ShizukuHelper.isGranted()){
            AlertDialog.Builder(this)
                .setTitle("SHIZUKU REQUIRED")
                .setMessage("BalzyGameSpace memakai Shizuku untuk mengetahui apakah game yang dipilih benar-benar berada di foreground. Game Panel tidak akan tampil di Home atau aplikasi lain.")
                .setNegativeButton("CANCEL",null)
                .setPositiveButton("GRANT") { _,_ ->
                    ShizukuHelper.requestPermission()
                    Toast.makeText(this,"Grant BalzyGameSpace di Shizuku, lalu Launch Game lagi.",Toast.LENGTH_LONG).show()
                }.show()
            return
        }
        val service=Intent(this,GamePanelService::class.java)
            .putExtra("game",g.label)
            .putExtra("gamePackage",g.pkg)
        ContextCompat.startForegroundService(this,service)
        startActivity(i)
    }

    private fun showShizukuSetup(){
        AlertDialog.Builder(this)
            .setTitle("SHIZUKU / WIRELESS DEBUGGING")
            .setMessage("Untuk Game Panel yang hanya aktif saat game dimainkan, BalzyGameSpace membutuhkan Shizuku. Android 11+ dapat menjalankan Shizuku melalui Wireless Debugging tanpa root. Pasang dan jalankan Shizuku, lalu berikan izin ke BalzyGameSpace.")
            .setNegativeButton("CLOSE",null)
            .setNeutralButton("WIRELESS DEBUGGING"){_,_->ShizukuHelper.openWirelessDebugging(this)}
            .setPositiveButton("OPEN SHIZUKU"){_,_->ShizukuHelper.openShizuku(this)}
            .show()
    }
    private fun startPanel(){if(!Settings.canDrawOverlays(this)){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")));return};ContextCompat.startForegroundService(this,Intent(this,GamePanelService::class.java).putExtra("openNow",true))}

    private fun labs(){AlertDialog.Builder(this).setTitle("GAME-LABS").setItems(arrayOf("Crosshair Overlay","Game Volume","Screen Brightness","Do Not Disturb","Screen Recorder","Open Game Panel")){_,w->when(w){0->crosshair();1->volume();2->brightness();3->dnd();4->startPanel();5->startPanel()}}.show()}
    private fun crosshair(){if(!Settings.canDrawOverlays(this)){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")));return};ContextCompat.startForegroundService(this,Intent(this,GamePanelService::class.java).putExtra("crosshair",true))}
    private fun volume(){val am=getSystemService(AUDIO_SERVICE) as android.media.AudioManager;val seek=SeekBar(this).apply{max=am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC);progress=am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC);setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,f:Boolean){if(f)am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC,p,0)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){} })};AlertDialog.Builder(this).setTitle("GAME VOLUME").setView(seek).setPositiveButton("DONE",null).show()}
    private fun brightness(){if(!Settings.System.canWrite(this)){startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:$packageName")));return};val seek=SeekBar(this).apply{max=255;progress=Settings.System.getInt(contentResolver,Settings.System.SCREEN_BRIGHTNESS,128);setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,f:Boolean){if(f)Settings.System.putInt(contentResolver,Settings.System.SCREEN_BRIGHTNESS,p)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){} })};AlertDialog.Builder(this).setTitle("SCREEN BRIGHTNESS").setView(seek).setPositiveButton("DONE",null).show()}
    private fun dnd(){startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))}
    private fun boost(){Toast.makeText(this,"Focus mode: game panel ready. OEM-level CPU/GPU boosting is not exposed to normal Android apps.",Toast.LENGTH_LONG).show()}
    private fun settings(){
        val shizuku=if(ShizukuHelper.isGranted())"GRANTED" else "REQUIRED"
        AlertDialog.Builder(this)
            .setTitle("BalzyGameSpace")
            .setItems(arrayOf(
                "Overlay permission",
                "Modify brightness permission",
                "DND access",
                "Battery optimization",
                "Shizuku / Wireless Debugging  •  $shizuku",
                "About"
            )){_,w->
                when(w){
                    0->startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))
                    1->startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:$packageName")))
                    2->dnd()
                    3->runCatching{startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:$packageName")))}
                    4->showShizukuSetup()
                    5->AlertDialog.Builder(this).setTitle("BalzyGameSpace").setMessage("Black / Red Game Space\nManual game library\nInteractive in-game edge panel\nShizuku foreground detection\nVersion 1.0.3").setPositiveButton("OK",null).show()
                }
            }.show()
    }
    private fun requestNotify(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),20)}
}
