package com.balzy.gamespace

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var gamesContainer: LinearLayout
    private val red = Color.rgb(255, 27, 45)
    private val bg = Color.rgb(5, 5, 5)
    private val muted = Color.rgb(154, 154, 154)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestNotificationPermission()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 18, 18, 12)
        }
        val logo = ImageView(this).apply { setImageResource(R.drawable.ic_balzy) }
        header.addView(logo, LinearLayout.LayoutParams(46, 46))
        val brand = TextView(this).apply {
            text = "BalzyGameSpace"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(10,0,0,0)
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = TextView(this).apply {
            text = "⚙"
            textSize = 26f
            setTextColor(red)
            setOnClickListener { showSettings() }
        }
        header.addView(settings, LinearLayout.LayoutParams(45, 50))
        root.addView(header)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 4, 16, 30)
        }
        scroll.addView(content)

        val hero = card()
        val heroTitle = text("Main Game", 23f, Color.WHITE, true)
        hero.addView(heroTitle)
        hero.addView(text("Kelola game, aktifkan booster, dan buka panel gaming BalzyGameSpace.", 13f, muted, false))
        val startPanel = button("AKTIFKAN PANEL DALAM GAME")
        startPanel.setOnClickListener { toggleOverlay() }
        hero.addView(startPanel, LinearLayout.LayoutParams(-1, 52))
        content.addView(hero)

        content.addView(sectionTitle("Game Saya"))
        gamesContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(gamesContainer)
        loadGames()

        content.addView(sectionTitle("Game-Labs"))
        val labs = listOf(
            "🚀  Game Booster" to "Mode gaming & optimasi",
            "📊  Performance Monitor" to "FPS, CPU, RAM, suhu",
            "🎯  Touch Tools" to "Touch indicator & tools",
            "🎥  Screen Recorder" to "Rekam layar saat bermain",
            "🔕  DND Mode" to "Kurangi gangguan notifikasi"
        )
        labs.forEach { (a,b) ->
            val c = smallCard(a,b)
            c.setOnClickListener { showTool(a) }
            content.addView(c)
        }

        content.addView(sectionTitle("Tentang"))
        val about = card()
        about.addView(text("BalzyGameSpace", 17f, Color.WHITE, true))
        about.addView(text("Gaming Space original dengan UI hitam-merah. Fitur overlay menggunakan API Android resmi.", 12f, muted, false))
        content.addView(about)

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun loadGames() {
        gamesContainer.removeAllViews()
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .take(30)

        if (apps.isEmpty()) {
            gamesContainer.addView(text("Belum ada aplikasi yang bisa diluncurkan.", 13f, muted, false))
            return
        }

        apps.take(12).forEach { app ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(14, 10, 10, 10)
                background = rounded(Color.rgb(17,17,17), 16f)
                setOnClickListener { launchApp(app.packageName) }
            }
            val icon = ImageView(this).apply { setImageDrawable(app.loadIcon(pm)) }
            row.addView(icon, LinearLayout.LayoutParams(52,52))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12,0,0,0) }
            info.addView(text(app.loadLabel(pm).toString(), 15f, Color.WHITE, true))
            info.addView(text(app.packageName, 10f, muted, false))
            row.addView(info, LinearLayout.LayoutParams(0,-2,1f))
            val play = TextView(this).apply { text="▶"; textSize=18f; setTextColor(red) }
            row.addView(play, LinearLayout.LayoutParams(42,52))
            val lp = LinearLayout.LayoutParams(-1, 72); lp.bottomMargin = 8
            gamesContainer.addView(row, lp)
        }
    }

    private fun launchApp(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) {
            Toast.makeText(this, "Membuka game...", Toast.LENGTH_SHORT).show()
            startActivity(i)
        }
    }

    private fun toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Izinkan tampil di atas aplikasi lain, lalu tekan tombol lagi.", Toast.LENGTH_LONG).show()
            return
        }
        val i = Intent(this, GamePanelService::class.java)
        if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(this, i)
        else startService(i)
        Toast.makeText(this, "Panel BalzyGameSpace aktif. Swipe dari tepi kiri ke tengah.", Toast.LENGTH_LONG).show()
    }

    private fun showTool(name: String) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(name)
            .setMessage(
                when {
                    name.contains("Booster") -> "UI Game Booster BalzyGameSpace siap digunakan. Mode yang membutuhkan akses sistem akan meminta permission Android."
                    name.contains("Performance") -> "Monitor dasar dan panel UI tersedia. Nilai performa dapat berbeda menurut perangkat."
                    name.contains("Touch") -> "Touch tools UI tersedia. Mapping otomatis memerlukan aksesibilitas dan dukungan game/perangkat."
                    name.contains("Recorder") -> "Screen Recorder menggunakan MediaProjection pada implementasi native lanjutan."
                    else -> "Fitur BalzyGameSpace."
                }
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showSettings() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Settings")
            .setMessage("BalzyGameSpace 1.0.0\n\n• Tema: Black / Red\n• Edge panel: kiri\n• Overlay: Android System\n• UI Game-Labs aktif")
            .setPositiveButton("Tutup", null)
            .setNeutralButton("Izin Overlay") { _, _ ->
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }.show()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(18,18,18,18)
        background = getDrawable(R.drawable.card_bg)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin=14
        layoutParams=lp
    }

    private fun smallCard(title:String, sub:String): LinearLayout {
        val c=card()
        c.setPadding(16,12,16,12)
        val line=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        val icon=TextView(this).apply{text=title.take(2);textSize=16f;setTextColor(red);gravity=Gravity.CENTER;background=rounded(Color.rgb(55,10,15),50f)}
        line.addView(icon,LinearLayout.LayoutParams(48,48))
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,0,0,0)}
        box.addView(text(title.drop(3),15f,Color.WHITE,true))
        box.addView(text(sub,11f,muted,false))
        line.addView(box,LinearLayout.LayoutParams(0,-2,1f))
        line.addView(text("›",26f,red,false))
        c.addView(line)
        return c
    }

    private fun sectionTitle(s:String)=text(s,18f,Color.WHITE,true).apply{setPadding(4,8,4,10)}
    private fun text(s:String,size:Float,color:Int,bold:Boolean)=TextView(this).apply{
        text=s;textSize=size;setTextColor(color);if(bold)typeface=android.graphics.Typeface.DEFAULT_BOLD
        setPadding(0,4,0,7)
    }
    private fun button(s:String)=TextView(this).apply{
        text=s;textSize=12f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);typeface=android.graphics.Typeface.DEFAULT_BOLD
        background=getDrawable(R.drawable.red_button);setPadding(10,0,10,0)
    }
    private fun rounded(color:Int,r:Float)=GradientDrawable().apply{setColor(color);cornerRadius=r}
}

