# BalzyGameSpace 1.0.2

Black/red Android gaming hub with an original visual direction inspired by modern Game Space apps.

### Changes
- Manual **ADD GAME** only. Installed apps are not automatically inserted into the library.
- Game cards use the real application icon and a real launch action.
- Long-press a game to remove only its BalzyGameSpace shortcut.
- Animated BalzyGameSpace splash before entering the dashboard.
- Red/black layered dashboard, compact game grid, Game-Labs and bottom navigation.
- No emoji used for feature icons; feature controls use vector icons.
- Launching a selected game starts the overlay service so the left edge can be swiped toward the center.
- Game Panel buttons have real Android actions where available: volume, brightness, DND settings and crosshair overlay.
- System/OEM-only functions are not falsely represented as working; Android permissions/limitations are respected.

### Build
Use GitHub Actions -> Build BalzyGameSpace APK -> Run workflow.


## System Permission Center
- SYSTEM_ALERT_WINDOW: floating Game Panel / crosshair
- POST_NOTIFICATIONS: foreground service notification
- WRITE_SETTINGS: brightness control
- Notification Policy Access: DND
- Usage Access: activity/game monitoring access
- Battery optimization: optional foreground reliability
- MediaProjection: screen recording requires Android user consent per session

All permissions use official Android Settings or runtime consent. A normal APK cannot silently grant itself privileged/root permissions.


## Shizuku + Wireless Debugging
BalzyGameSpace can use Shizuku as an optional elevated shell bridge for functions that require shell/ADB-level access. On Android 11+, Shizuku can be started using the phone's Wireless Debugging feature without root. The user must install/start Shizuku and explicitly grant BalzyGameSpace permission.

### Foreground-only Game Panel
The floating panel is NOT displayed on the home screen or while using another app. When a game is launched from the manual library:
1. BalzyGameSpace starts the panel service.
2. Shizuku checks the current foreground package.
3. The edge handle appears only when the selected game package is foreground.
4. Leaving the game immediately hides the handle and closes the panel.
5. Returning to the same game makes the handle available again.

Shizuku's API supports ADB/shell-backed access, and Wireless Debugging on Android 11+ is the supported non-root startup route. See the official Shizuku API documentation for the permission model. 


## Shizuku / Wireless Debugging
The in-game panel uses Shizuku for foreground-game detection. On Android 11+, Shizuku can be started through Wireless Debugging without root. The user must install/start Shizuku and explicitly grant BalzyGameSpace permission.

### Panel visibility rule
- Home screen: NO panel
- BalzyGameSpace itself: NO panel
- Other apps: NO panel
- Selected game in foreground: panel edge handle appears
- Swipe left edge -> center: panel opens
- Leave the selected game: panel and handle are removed
- Return to the selected game: handle becomes available again

The app does not silently obtain privileged access. Shizuku/Wireless Debugging still requires explicit user setup and authorization.
