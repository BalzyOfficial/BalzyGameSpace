# BalzyGameSpace

Native Android gaming space dengan tema black/red.

## Fitur versi 1.0
- Splash / opening BalzyGameSpace
- Game Space: mendeteksi aplikasi yang punya launcher activity
- Launch game/app langsung
- Game-Labs UI
- Overlay Game Panel
- Edge swipe: dari tepi kiri ke tengah
- FPS/CPU/RAM/TEMP UI
- Booster / Monitor / Touch / Screenshot / Record / DND / Crosshair / Lock Touch UI
- GitHub Actions build APK otomatis

## Build lewat GitHub
1. Buat repository baru.
2. Upload seluruh isi folder project ini.
3. Push ke `main`.
4. Buka tab **Actions**.
5. Workflow **Build BalzyGameSpace APK** akan berjalan.
6. Setelah selesai, buka hasil run dan ambil artifact `BalzyGameSpace-debug`.

## Catatan Android
Overlay membutuhkan izin **Tampil di atas aplikasi lain**.
Service menggunakan foreground notification supaya panel dapat tetap berjalan.
Beberapa fungsi tingkat sistem (FPS asli, screen recording, key mapping, DND, dan optimasi performa) membutuhkan API/permission Android khusus dan dukungan perangkat. Versi awal menyediakan UI dan kerangka native untuk fungsi tersebut.
